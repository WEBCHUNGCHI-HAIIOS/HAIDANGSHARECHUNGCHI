import "dotenv/config";
import { PrismaClient } from "@prisma/client";
const prisma = new PrismaClient();
const categories = [
  ["Free Fire", "free-fire"], ["Liên Quân Mobile", "lien-quan"],
  ["PUBG Mobile", "pubg-mobile"], ["Roblox", "roblox"], ["Steam", "steam"],
  ["Facebook", "facebook"], ["TikTok", "tiktok"], ["Instagram", "instagram"],
  ["YouTube", "youtube"], ["Telegram", "telegram"], ["Dịch vụ MMO", "dich-vu-mmo"],
  ["Phần mềm & AI", "phan-mem-ai"]
];
for (const [name, slug] of categories) {
  await prisma.category.upsert({ where: { slug }, update: { name }, create: { name, slug } });
}
console.log("Đã tạo danh mục HỒNG HẢI MMO.");
await prisma.$disconnect();
