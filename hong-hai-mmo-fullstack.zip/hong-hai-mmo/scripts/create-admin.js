import "dotenv/config";
import argon2 from "argon2";
import { PrismaClient } from "@prisma/client";
const prisma = new PrismaClient();
const { ADMIN_NAME, ADMIN_EMAIL, ADMIN_PASSWORD } = process.env;
if (!ADMIN_NAME || !ADMIN_EMAIL || !ADMIN_PASSWORD || ADMIN_PASSWORD.length < 16) {
  throw new Error("Cần ADMIN_NAME, ADMIN_EMAIL và ADMIN_PASSWORD tối thiểu 16 ký tự trong .env");
}
const email = ADMIN_EMAIL.toLowerCase();
const passwordHash = await argon2.hash(ADMIN_PASSWORD, { type: argon2.argon2id });
const user = await prisma.user.upsert({
  where: { email },
  update: { name: ADMIN_NAME, passwordHash, role: "SUPER_ADMIN", isActive: true },
  create: { name: ADMIN_NAME, email, passwordHash, role: "SUPER_ADMIN", wallet: { create: {} } },
  select: { id: true, name: true, email: true, role: true }
});
console.log("Super Admin ready:", user);
await prisma.$disconnect();
