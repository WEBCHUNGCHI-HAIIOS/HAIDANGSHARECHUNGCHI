const $ = s => document.querySelector(s);
let selectedCategory = "";
let authMode = "login";
async function api(url, options={}) {
  const response = await fetch(url, { credentials:"same-origin", headers:{"Content-Type":"application/json", ...(options.headers||{})}, ...options });
  const data = await response.json().catch(()=>({}));
  if (!response.ok) throw new Error(data.error || "Có lỗi xảy ra");
  return data;
}
function money(value){return new Intl.NumberFormat("vi-VN",{style:"currency",currency:"VND",maximumFractionDigits:0}).format(value)}
async function loadCategories(){
  const {categories=[]}=await api("/api/products/categories");
  $("#categoryList").innerHTML = `<button class="chip active" data-slug="">Tất cả</button>`+categories.map(c=>`<button class="chip" data-slug="${c.slug}">${c.name}</button>`).join("");
  $("#categoryList").addEventListener("click",e=>{
    const b=e.target.closest("button[data-slug]");if(!b)return;
    selectedCategory=b.dataset.slug;
    document.querySelectorAll(".chip").forEach(x=>x.classList.toggle("active",x===b));
    loadProducts();
  });
}
async function loadProducts(){
  const q=encodeURIComponent($("#search").value.trim());
  const {products=[]}=await api(`/api/products?q=${q}&category=${encodeURIComponent(selectedCategory)}`);
  $("#productGrid").innerHTML=products.length?products.map(p=>`<article class="product"><div class="tag">${p.category.name} · Còn ${p.stock}</div><h3>${escapeHtml(p.title)}</h3><p>${escapeHtml(p.description.slice(0,130))}</p><div class="price">${money(p.price)}</div><button class="ghost" data-buy="${p.id}">Đăng nhập để mua</button></article>`).join(""):`<div class="empty">Chưa có sản phẩm phù hợp. Sản phẩm mới sẽ xuất hiện tại đây sau khi được duyệt.</div>`;
}
function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
let currentUser=null;
async function refreshUser(){const d=await api("/api/auth/me");currentUser=d.user;if(currentUser){$("#loginOpen").textContent=currentUser.name;$("#registerOpen").textContent="Tài khoản";}}
function openAuth(mode){authMode=mode;$("#authTitle").textContent=mode==="login"?"Đăng nhập":"Tạo tài khoản";$("#nameWrap").classList.toggle("hidden",mode==="login");$("#authMessage").textContent="";$("#authDialog").showModal();}
$("#loginOpen").onclick=()=>openAuth("login");$("#registerOpen").onclick=()=>openAuth("register");$("#closeDialog").onclick=()=>$("#authDialog").close();
$("#authForm").addEventListener("submit",async e=>{
  e.preventDefault();const f=new FormData(e.currentTarget);const body=Object.fromEntries(f.entries());
  try{const d=await api(`/api/auth/${authMode}`,{method:"POST",body:JSON.stringify(body)});currentUser=d.user;$("#authMessage").textContent="Thành công!";$("#authDialog").close();await refreshUser();}
  catch(err){$("#authMessage").textContent=err.message;}
});
$("#search").addEventListener("input",()=>{clearTimeout(window.searchTimer);window.searchTimer=setTimeout(loadProducts,250);});
$("#productGrid").addEventListener("click",e=>{if(e.target.dataset.buy)openAuth("login");});
Promise.all([loadCategories(),loadProducts(),refreshUser()]).catch(e=>console.error(e));
