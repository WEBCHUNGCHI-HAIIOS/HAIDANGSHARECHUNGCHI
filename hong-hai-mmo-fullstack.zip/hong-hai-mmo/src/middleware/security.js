export function sameOriginForMutations(req, res, next) {
  if (["GET", "HEAD", "OPTIONS"].includes(req.method)) return next();
  const origin = req.get("origin");
  if (!origin) return res.status(403).json({ error: "Thiếu Origin hợp lệ." });
  try {
    if (new URL(origin).origin !== process.env.FRONTEND_ORIGIN) {
      return res.status(403).json({ error: "Origin không hợp lệ." });
    }
  } catch {
    return res.status(403).json({ error: "Origin không hợp lệ." });
  }
  next();
}
