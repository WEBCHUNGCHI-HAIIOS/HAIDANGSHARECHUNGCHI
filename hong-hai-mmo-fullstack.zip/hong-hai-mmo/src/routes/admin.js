import { Router } from "express";
import { prisma } from "../lib/prisma.js";
import { requireAuth, requireRole } from "../middleware/auth.js";

const router = Router();
router.use(requireAuth, requireRole("ADMIN", "SUPER_ADMIN", "MANAGER", "FINANCE"));

router.get("/overview", async (_req, res, next) => {
  try {
    const [users, products, orders, pendingDeposits] = await Promise.all([
      prisma.user.count(), prisma.product.count(), prisma.order.count(),
      prisma.deposit.count({ where: { status: "PENDING" } })
    ]);
    res.json({ users, products, orders, pendingDeposits });
  } catch (e) { next(e); }
});

router.get("/deposits", requireRole("ADMIN", "SUPER_ADMIN", "FINANCE"), async (_req, res, next) => {
  try {
    res.json({ deposits: await prisma.deposit.findMany({
      where: { status: "PENDING" }, include: { user: { select: { name: true, email: true } } },
      orderBy: { createdAt: "asc" }, take: 100
    })});
  } catch (e) { next(e); }
});

// Manual finance approval is intentionally not exposed as a blind "mark paid" button.
// Implement it only after matching bank/provider transaction evidence and recording an audit trail.
router.get("/products/pending", requireRole("ADMIN", "SUPER_ADMIN", "MANAGER"), async (_req, res, next) => {
  try { res.json({ products: await prisma.product.findMany({ where: { status: "DRAFT" }, include: { seller: { select: { name: true, email: true } } }, take: 100 } }); }
  catch (e) { next(e); }
});
export default router;
