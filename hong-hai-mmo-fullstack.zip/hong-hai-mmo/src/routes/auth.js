import { Router } from "express";
import argon2 from "argon2";
import { z } from "zod";
import { prisma } from "../lib/prisma.js";
import { requireAuth } from "../middleware/auth.js";

const router = Router();
const registerSchema = z.object({
  name: z.string().trim().min(2).max(60),
  email: z.email().max(190).transform(v => v.toLowerCase()),
  password: z.string().min(12).max(128)
});

router.post("/register", async (req, res, next) => {
  try {
    const data = registerSchema.parse(req.body);
    const passwordHash = await argon2.hash(data.password, { type: argon2.argon2id });
    const user = await prisma.$transaction(async tx => {
      const created = await tx.user.create({
        data: { name: data.name, email: data.email, passwordHash, wallet: { create: {} } },
        select: { id: true, name: true, email: true, role: true }
      });
      return created;
    });
    req.session.user = user;
    res.status(201).json({ user });
  } catch (e) {
    if (e.code === "P2002") return res.status(409).json({ error: "Email đã được sử dụng." });
    next(e);
  }
});

router.post("/login", async (req, res, next) => {
  try {
    const email = z.email().parse(String(req.body.email || "").toLowerCase());
    const password = z.string().min(1).parse(req.body.password);
    const user = await prisma.user.findUnique({ where: { email } });
    if (!user || !user.isActive || !(await argon2.verify(user.passwordHash, password))) {
      return res.status(401).json({ error: "Email hoặc mật khẩu không chính xác." });
    }
    await new Promise((resolve, reject) => req.session.regenerate(err => err ? reject(err) : resolve()));
    req.session.user = { id: user.id, name: user.name, email: user.email, role: user.role };
    res.json({ user: req.session.user });
  } catch (e) { next(e); }
});

router.post("/logout", requireAuth, (req, res, next) => {
  req.session.destroy(err => err ? next(err) : res.clearCookie("hh.sid").json({ ok: true }));
});

router.get("/me", (req, res) => res.json({ user: req.session.user || null }));
export default router;
