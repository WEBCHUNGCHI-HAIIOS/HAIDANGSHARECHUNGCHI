import { Router } from "express";
import { z } from "zod";
import { prisma } from "../lib/prisma.js";
import { requireAuth, requireRole } from "../middleware/auth.js";

const router = Router();

router.get("/", async (req, res, next) => {
  try {
    const q = String(req.query.q || "").slice(0, 100);
    const category = req.query.category ? String(req.query.category) : undefined;
    const products = await prisma.product.findMany({
      where: { status: "ACTIVE", ...(category ? { category: { slug: category } } : {}),
        ...(q ? { OR: [{ title: { contains: q, mode: "insensitive" } }, { description: { contains: q, mode: "insensitive" } }] } : {}) },
      select: { id: true, title: true, slug: true, description: true, price: true, stock: true, imageUrl: true, category: { select: { name: true, slug: true } } },
      orderBy: { createdAt: "desc" }, take: 60
    });
    res.json({ products });
  } catch (e) { next(e); }
});

router.get("/categories", async (_req, res, next) => {
  try { res.json({ categories: await prisma.category.findMany({ orderBy: { name: "asc" } }) }); }
  catch (e) { next(e); }
});

router.post("/", requireAuth, requireRole("SELLER", "ADMIN", "SUPER_ADMIN"), async (req, res, next) => {
  try {
    const data = z.object({
      title: z.string().trim().min(4).max(120),
      description: z.string().trim().min(10).max(5000),
      price: z.number().int().min(1000).max(100000000),
      stock: z.number().int().min(1).max(10000),
      categoryId: z.string(),
      imageUrl: z.url().optional()
    }).parse(req.body);
    const slug = `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
    const product = await prisma.product.create({ data: { ...data, slug, sellerId: req.session.user.id, status: "DRAFT" } });
    res.status(201).json({ product, message: "Sản phẩm đã gửi duyệt; chưa được hiển thị công khai." });
  } catch (e) { next(e); }
});
export default router;
