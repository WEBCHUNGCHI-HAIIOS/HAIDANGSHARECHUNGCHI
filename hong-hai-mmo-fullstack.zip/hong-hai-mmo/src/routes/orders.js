import { Router } from "express";
import { z } from "zod";
import { prisma } from "../lib/prisma.js";
import { requireAuth } from "../middleware/auth.js";

const router = Router();
router.use(requireAuth);

router.get("/", async (req, res, next) => {
  try {
    const orders = await prisma.order.findMany({
      where: { userId: req.session.user.id },
      include: { product: { select: { title: true, imageUrl: true } } },
      orderBy: { createdAt: "desc" }, take: 50
    });
    res.json({ orders });
  } catch (e) { next(e); }
});

router.post("/", async (req, res, next) => {
  try {
    const { productId, quantity } = z.object({
      productId: z.string(), quantity: z.number().int().min(1).max(10)
    }).parse(req.body);
    const order = await prisma.$transaction(async tx => {
      const product = await tx.product.findUnique({ where: { id: productId } });
      if (!product || product.status !== "ACTIVE" || product.stock < quantity) {
        throw Object.assign(new Error("Sản phẩm không còn đủ hàng."), { status: 409 });
      }
      const wallet = await tx.wallet.findUnique({ where: { userId: req.session.user.id } });
      const total = product.price * quantity;
      if (!wallet || wallet.balance < total) {
        throw Object.assign(new Error("Số dư ví không đủ."), { status: 409 });
      }
      // Conditional stock decrement prevents overselling under concurrent requests.
      const stockUpdate = await tx.product.updateMany({
        where: { id: productId, status: "ACTIVE", stock: { gte: quantity } },
        data: { stock: { decrement: quantity }, ...(product.stock === quantity ? { status: "SOLD_OUT" } : {}) }
      });
      if (stockUpdate.count !== 1) throw Object.assign(new Error("Sản phẩm vừa hết hàng."), { status: 409 });
      const walletUpdate = await tx.wallet.updateMany({
        where: { id: wallet.id, balance: { gte: total } }, data: { balance: { decrement: total } }
      });
      if (walletUpdate.count !== 1) throw Object.assign(new Error("Số dư ví không đủ."), { status: 409 });
      const balanceAfter = wallet.balance - total;
      await tx.walletTransaction.create({ data: {
        walletId: wallet.id, type: "PURCHASE", amount: -total, balanceAfter,
        reference: `ORDER-${crypto.randomUUID()}`, description: `Thanh toán ${product.title}`
      }});
      return tx.order.create({ data: {
        userId: req.session.user.id, productId, quantity, unitPrice: product.price, total
      }});
    }, { isolationLevel: "Serializable" });
    res.status(201).json({ order, message: "Đơn hàng đã được tạo và chuyển sang xử lý." });
  } catch (e) { next(e); }
});
export default router;
