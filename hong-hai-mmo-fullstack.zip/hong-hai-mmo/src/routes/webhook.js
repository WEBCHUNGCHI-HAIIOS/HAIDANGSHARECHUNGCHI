import { Router } from "express";
import { createHmac, timingSafeEqual } from "node:crypto";
import { prisma } from "../lib/prisma.js";

const router = Router();

// Provider-specific adapter required: signature header, payload schema, event ID and transaction reference
// must match the selected payment gateway's official documentation.
router.post("/payments", async (req, res, next) => {
  try {
    const secret = process.env.PAYMENT_WEBHOOK_SECRET;
    const signature = req.get("x-provider-signature") || "";
    if (!secret || !req.rawBody) return res.status(503).json({ error: "Webhook chưa được cấu hình." });
    const expected = createHmac("sha256", secret).update(req.rawBody).digest("hex");
    const a = Buffer.from(signature);
    const b = Buffer.from(expected);
    if (a.length !== b.length || !timingSafeEqual(a, b)) return res.status(401).json({ error: "Chữ ký không hợp lệ." });

    const event = req.body;
    // Expected normalized example: { id, type:"deposit.paid", depositId, providerRef, amount }
    if (!event?.id || event.type !== "deposit.paid" || !event.depositId || !event.providerRef || !Number.isInteger(event.amount)) {
      return res.status(400).json({ error: "Payload webhook không hợp lệ." });
    }

    await prisma.$transaction(async tx => {
      await tx.webhookEvent.create({ data: { id: String(event.id), provider: "CONFIGURED_GATEWAY" } });
      const deposit = await tx.deposit.findUnique({ where: { id: String(event.depositId) } });
      if (!deposit || deposit.status !== "PENDING" || deposit.amount !== event.amount) {
        throw new Error("Deposit không khớp hoặc không ở trạng thái chờ.");
      }
      const wallet = await tx.wallet.findUnique({ where: { userId: deposit.userId } });
      const updated = await tx.deposit.updateMany({
        where: { id: deposit.id, status: "PENDING" },
        data: { status: "COMPLETED", providerRef: String(event.providerRef) }
      });
      if (updated.count !== 1) throw new Error("Deposit đã được xử lý.");
      const newWallet = await tx.wallet.update({ where: { id: wallet.id }, data: { balance: { increment: deposit.amount } } });
      await tx.walletTransaction.create({ data: {
        walletId: wallet.id, type: "DEPOSIT", amount: deposit.amount, balanceAfter: newWallet.balance,
        reference: `DEPOSIT-${deposit.id}`, description: "Nạp tiền đã xác minh qua cổng thanh toán"
      }});
    });
    res.json({ received: true });
  } catch (e) {
    if (e.code === "P2002") return res.json({ received: true, duplicate: true });
    next(e);
  }
});
export default router;
