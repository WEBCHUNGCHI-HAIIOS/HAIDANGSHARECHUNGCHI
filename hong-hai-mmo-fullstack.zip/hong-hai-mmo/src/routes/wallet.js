import { Router } from "express";
import { randomUUID } from "node:crypto";
import { z } from "zod";
import { prisma } from "../lib/prisma.js";
import { requireAuth } from "../middleware/auth.js";

const router = Router();
router.use(requireAuth);

router.get("/", async (req, res, next) => {
  try {
    const wallet = await prisma.wallet.findUnique({ where: { userId: req.session.user.id }, include: {
      entries: { orderBy: { createdAt: "desc" }, take: 30 }
    }});
    res.json({ wallet });
  } catch (e) { next(e); }
});

router.post("/deposits", async (req, res, next) => {
  try {
    const { amount } = z.object({ amount: z.number().int().min(10000).max(50000000) }).parse(req.body);
    const deposit = await prisma.deposit.create({ data: {
      userId: req.session.user.id, amount, provider: "MANUAL_PENDING", idempotencyKey: randomUUID()
    }});
    // A pending request never credits the wallet. Finance staff/provider webhook must verify payment.
    res.status(201).json({ deposit, message: "Yêu cầu nạp đã tạo ở trạng thái chờ xác minh. Ví chưa được cộng tiền." });
  } catch (e) { next(e); }
});
export default router;
