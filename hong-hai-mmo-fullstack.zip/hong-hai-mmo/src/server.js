import "dotenv/config";
import express from "express";
import session from "express-session";
import connectPgSimple from "connect-pg-simple";
import helmet from "helmet";
import cors from "cors";
import rateLimit from "express-rate-limit";
import path from "node:path";
import { fileURLToPath } from "node:url";
import pg from "pg";
import authRoutes from "./routes/auth.js";
import productRoutes from "./routes/products.js";
import walletRoutes from "./routes/wallet.js";
import orderRoutes from "./routes/orders.js";
import adminRoutes from "./routes/admin.js";
import webhookRoutes from "./routes/webhook.js";
import { sameOriginForMutations } from "./middleware/security.js";

const app = express();
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const pool = new pg.Pool({ connectionString: process.env.DATABASE_URL });
const PgSession = connectPgSimple(session);

if (!process.env.SESSION_SECRET || process.env.SESSION_SECRET.length < 32) {
  throw new Error("SESSION_SECRET phải có ít nhất 32 ký tự ngẫu nhiên.");
}
if (!process.env.FRONTEND_ORIGIN) throw new Error("Thiếu FRONTEND_ORIGIN.");

app.disable("x-powered-by");
app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors({ origin: process.env.FRONTEND_ORIGIN, credentials: true }));
app.use(express.json({ limit: "1mb", verify: (req, _res, buf) => { req.rawBody = Buffer.from(buf); } }));
app.use(sameOriginForMutations);
app.use(session({
  store: new PgSession({ pool, tableName: "user_sessions", createTableIfMissing: true }),
  name: "hh.sid", secret: process.env.SESSION_SECRET,
  resave: false, saveUninitialized: false,
  cookie: { httpOnly: true, secure: process.env.COOKIE_SECURE === "true", sameSite: "lax", maxAge: 1000 * 60 * 60 * 12 }
}));
app.use("/api/auth", rateLimit({ windowMs: 15 * 60 * 1000, limit: 30 }), authRoutes);
app.use("/api/products", productRoutes);
app.use("/api/wallet", walletRoutes);
app.use("/api/orders", orderRoutes);
app.use("/api/admin", adminRoutes);
app.use("/api/webhooks", webhookRoutes);

app.use(express.static(path.join(__dirname, "../public")));
app.get("/api/health", (_req, res) => res.json({ ok: true, service: "HONG HAI MMO" }));
app.use((err, _req, res, _next) => {
  console.error(err);
  if (err.name === "ZodError") return res.status(400).json({ error: "Dữ liệu gửi lên không hợp lệ.", details: err.issues });
  res.status(err.status || 500).json({ error: err.status ? err.message : "Đã xảy ra lỗi máy chủ." });
});

const port = Number(process.env.PORT || 4000);
app.listen(port, () => console.log(`HỒNG HẢI MMO running: http://localhost:${port}`));
