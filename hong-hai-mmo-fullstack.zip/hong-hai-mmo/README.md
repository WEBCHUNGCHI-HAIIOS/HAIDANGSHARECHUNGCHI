# HỒNG HẢI MMO — Full-stack starter

Marketplace starter cho mua bán tài khoản game, tài khoản mạng xã hội và dịch vụ số. Giao diện đen–xanh neon; backend Node.js/Express; PostgreSQL/Prisma.

## Có gì trong bản nền tảng này?

- Đăng ký/đăng nhập bằng email và mật khẩu Argon2id; session lưu PostgreSQL.
- Vai trò CUSTOMER, SELLER, SUPPORT, MANAGER, FINANCE, ADMIN, SUPER_ADMIN.
- Danh mục, tìm kiếm và danh sách sản phẩm đã được duyệt.
- Người bán có thể gửi sản phẩm để admin duyệt.
- Ví khách hàng, yêu cầu nạp tiền ở trạng thái PENDING.
- Tạo đơn hàng với kiểm tra số dư server-side, trừ ví và giảm tồn kho trong transaction.
- API quản trị tổng quan, danh sách sản phẩm chờ duyệt và yêu cầu nạp chờ xác minh.
- Khung webhook HMAC để tích hợp cổng thanh toán sau khi chọn nhà cung cấp.

## 1. Yêu cầu

- Node.js 20+ (khuyến nghị bản LTS hiện hành)
- Docker Desktop hoặc PostgreSQL 16+
- npm

## 2. Cài đặt local

```bash
# 1. Giải nén dự án
cd hong-hai-mmo

# 2. Cài dependencies
npm install

# 3. Tạo file cấu hình
cp .env.example .env
```

Mở `.env`, đổi `SESSION_SECRET` thành chuỗi ngẫu nhiên dài tối thiểu 32 ký tự. Đổi mật khẩu PostgreSQL trùng với `docker-compose.yml` hoặc cập nhật cả hai nơi. Không đưa `.env` lên GitHub.

```bash
# 4. Khởi động PostgreSQL
docker compose up -d db

# 5. Tạo Prisma client và database schema
npm run db:generate
npx prisma migrate dev --name init

# 6. Tạo danh mục mẫu
npm run db:seed

# 7. Tạo tài khoản Super Admin
npm run admin:create

# 8. Chạy website
npm run dev
```

Mở http://localhost:4000

## 3. Tạo Super Admin

Điền `ADMIN_NAME`, `ADMIN_EMAIL`, `ADMIN_PASSWORD` trong `.env`. Mật khẩu quản trị phải dài ít nhất 16 ký tự. Chạy `npm run admin:create`. Không dùng chung mật khẩu mẫu trong môi trường thật.

## 4. API hiện có

| Method | Endpoint | Mô tả |
|---|---|---|
| POST | `/api/auth/register` | Đăng ký |
| POST | `/api/auth/login` | Đăng nhập |
| POST | `/api/auth/logout` | Đăng xuất |
| GET | `/api/auth/me` | Người dùng hiện tại |
| GET | `/api/products` | Tìm kiếm sản phẩm |
| GET | `/api/products/categories` | Danh mục |
| POST | `/api/products` | Người bán gửi sản phẩm duyệt |
| GET | `/api/wallet` | Ví và lịch sử |
| POST | `/api/wallet/deposits` | Tạo yêu cầu nạp chờ xác minh |
| GET | `/api/orders` | Đơn hàng của tôi |
| POST | `/api/orders` | Tạo đơn, trừ ví server-side |
| GET | `/api/admin/overview` | Thống kê admin |
| GET | `/api/admin/deposits` | Nạp tiền chờ xác minh |
| GET | `/api/admin/products/pending` | Sản phẩm chờ duyệt |
| POST | `/api/webhooks/payments` | Khung webhook xác minh chữ ký |

## 5. Thanh toán thật — cần hoàn thiện theo nhà cung cấp

Không có cách an toàn để tự suy đoán nội dung chuyển khoản rồi tự cộng ví. Chọn một cổng thanh toán/ngân hàng có API hoặc webhook chính thức, sau đó triển khai adapter theo tài liệu của nhà cung cấp:
1. Tạo mã giao dịch duy nhất cho mỗi deposit.
2. Xác minh chữ ký webhook bằng secret do nhà cung cấp cấp.
3. Đối chiếu mã giao dịch, số tiền, tài khoản nhận và trạng thái giao dịch.
4. Chống xử lý lặp (idempotency) và ghi audit log.
5. Chỉ cộng ví trong transaction sau khi xác minh thành công.

Route webhook hiện tại là bộ khung chuẩn hóa, chưa phải tích hợp sẵn với bất kỳ ngân hàng/cổng thanh toán cụ thể nào. Không bật nhận tiền thật trước khi hoàn thiện và kiểm thử adapter.

## 6. Trước khi đưa lên Internet

Bản này là nền tảng MVP có thể chạy local, chưa phải hệ thống đã kiểm toán bảo mật hoặc sẵn sàng xử lý tiền thật. Trước khi production cần:
- HTTPS bắt buộc; `COOKIE_SECURE=true`; cấu hình `FRONTEND_ORIGIN` đúng domain.
- CSRF protection đầy đủ (đặc biệt nếu frontend và API khác origin), rate limit theo IP/tài khoản, MFA cho admin.
- Audit log bất biến cho thao tác admin/finance; quy trình duyệt nạp/rút và hoàn tiền hai bước.
- Tích hợp thanh toán chính thức, webhook idempotency và đối soát.
- Quy trình bàn giao tài khoản an toàn: không lưu mật khẩu dạng rõ; mã hóa secrets bằng KMS/envelope encryption, chỉ cho phép người mua được cấp quyền xem một lần; nhật ký truy cập và cơ chế thu hồi.
- Quy định người bán chứng minh quyền sở hữu/chuyển nhượng; cấm tài khoản chiếm đoạt, dữ liệu bị đánh cắp, tài khoản giả mạo hoặc hàng hóa vi phạm điều khoản nền tảng/pháp luật.
- Chính sách quyền riêng tư, điều khoản dịch vụ, hoàn tiền, bảo hành, xử lý khiếu nại và tuân thủ pháp luật Việt Nam.
- Backup database, giám sát lỗi, cảnh báo bất thường, kiểm thử tải và kiểm thử xâm nhập độc lập.

## 7. Kiến trúc thư mục

```text
hong-hai-mmo/
├── prisma/
│   ├── schema.prisma
│   └── seed.js
├── public/
│   ├── index.html
│   ├── styles.css
│   └── app.js
├── scripts/
│   └── create-admin.js
├── src/
│   ├── lib/prisma.js
│   ├── middleware/
│   ├── routes/
│   └── server.js
├── .env.example
├── docker-compose.yml
└── package.json
```

## 8. Ghi chú phạm vi

Bản đầu tiên cung cấp khung backend/frontend có thể chạy được. Các module như chat realtime, rút tiền, affiliate, voucher, membership, ticketing, đánh giá, giao hàng mã hóa, MFA, audit log chi tiết và tích hợp AI cần được triển khai thành các giai đoạn tiếp theo; không giả lập giao dịch thành công.
